package u1.entregable1;

import java.util.Scanner;

public class Ej1 {
	
	public static void main (String[]args) {
		
		Scanner sc = new Scanner(System.in);
		
		int suma = 0;
		
		int numtotal = 0 ;
		
		do {
		
		System.out.println("Introduce un número natural par");
		
		int numero = sc.nextInt();
		
		int par = numero%2;
		
		if(par==0 && numero >=1) {
			
			System.out.println("El número es natural par");
			
			suma = suma + numero ;
			
			numtotal++;
			
		}else if(par!=0 || numero<=0) {
			
			System.out.println("El número no es par o no es natural");
		
		}
		
		}while(suma <= 100);
		
		int media = suma/numtotal ;
		
		if (suma >= 100) {
			
			System.out.println("La suma es mayor a 100");
			
			System.out.println("La media total es: "+media);
				
		}
		
		
		
	}

}
