package u1.entregable1;

import java.util.Scanner;

public class Ej2 {
	
	public static void main (String[]args) {
		
		Scanner sc = new Scanner (System.in) ;
		
		int numerosecreto;
		int intentosfijos;
		int ayuda = 0;
		int ayudita = 0;
		int respuesta;
		int intentosusados = 0;
		boolean intentosestablecidos = false;
		boolean acierto = false;
		
		numerosecreto=(int)(Math.random()*25)+1;
		
		do {
		
		System.out.println("¿Cuántos intentos quieres para acertar el número?");
		
		intentosfijos = sc.nextInt();
		
		if (intentosfijos >=1) {
		
		System.out.println("Tendrás "+intentosfijos+" intentos para acertar el número secreto");
		
		intentosestablecidos=true;
		
		}else {
			
		System.out.println("Introduce un número mayor a 0, no puedes jugar si no lo intentas");
			
		}
		
		}while(intentosestablecidos==false);
		
			do {
			
			System.out.println("¿Quieres recibir ayuda?");
			System.out.println("1. Sí");
			System.out.println("2. No");
			
			ayudita = sc.nextInt();
			
			switch(ayudita) {
			
			case 1 : System.out.println("Has elegido la opción con ayudas");
					 ayuda=ayuda+1;
			break;
			
			case 2 : System.out.println("Has elegido la opción sin ayudas");
				 	 ayuda=ayuda+2;
			break;
				
			default: System.out.println("Elige una opción válida");
			}
		
		}while(ayudita >=3 );
			
		if(ayuda==1) {
	
			do{
				
				System.out.println("Introduce un número para adivinar el número secreto");
				
				respuesta = sc.nextInt();
				
				intentosusados++;
				
				if (respuesta > numerosecreto) {
					
					System.out.println("El número secreto es menor que tu número");
					
				}
				
				if(respuesta < numerosecreto) {
					
					System.out.println("El número secreto es mayor que tu numero");
					
				}
				
				if(respuesta != numerosecreto) {
					
					acierto = false;
					
				}else {
					
					acierto = true;
					
				}
				
			}while(intentosusados<intentosfijos && acierto==false);
			
			if(intentosusados==intentosfijos) {
				System.out.println("Se te han acabado los intentos");
			}
			if(acierto==true) {
				System.out.println("Enhorabuena, has acertado el número secreto");
			}
		}else if(ayuda==2) {
			do {
				
				System.out.println("Introduce un múmero para acertar el número secreto:");
				
				respuesta=sc.nextInt();
				
				intentosusados++;
				
				if(respuesta!=numerosecreto) {
					
					System.out.println("Has fallado, prueba otra vez");
					acierto = false;
					
				}
				if(respuesta == numerosecreto) {				
					acierto = true;
				}
				
			}while(intentosusados<intentosfijos);
			if(intentosusados==intentosfijos) {
				System.out.println("Se te han acabado los intentos");
			}
			if(acierto==true) {
				System.out.println("Enhorabuena, has acertado el número secreto");
			}
		}
	}
}
