package u1.entregable1;

import java.util.Scanner;

public class Ej3 {
	
	public static void main(String[]args) {
		
		int hamburguesabasica = 3 ;
		int hamburguesagourmet = 5 ;
		int dia = 0;
		int club = 0;
		
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Pedidos Burbur");
		
		System.out.println("¿Cuántas hamburguesas básicas quieres?");
		
		int respuestauno = sc.nextInt();
		
		System.out.println("Número de hamburguesas básicas: "+respuestauno);
		
		System.out.println("¿Cuántas hamburguesas gourmet quieres?");
		
		int respuestados = sc.nextInt();
		
		System.out.println("Número de hamburguesas gourmet: "+respuestados);
		
		do {
		
		System.out.println("¿Qué día de la semana es hoy?");
		System.out.println("1.Lunes");
		System.out.println("2.Martes");
		System.out.println("3.Miércoles");
		System.out.println("4.Jueves");
		System.out.println("5.Viernes");
		System.out.println("6.Sábado");
		System.out.println("7.Domingo");
		
		dia = sc.nextInt();
		
		switch(dia) {
		
		case 1 : System.out.println("Dia de la semana: Lunes");
		break;
		case 2 : System.out.println("Dia de la semana: Martes");
				 System.out.println("Hoy es Martes Locos!! 2 hamburguesas gourmet costarán 9€ en vez de 10€");
		break;
		case 3 : System.out.println("Dia de la semana: Miercoles");
				 System.out.println("Es miércoless de desmadre!! Las hamburguesas básicas cuestan 2€ en vez de 3€");
		break;
		case 4 : System.out.println("Dia de la semana: Jueves");
		break;
		case 5 : System.out.println("Dia de la semana: Viernes");
		break;
		case 6 : System.out.println("Dia de la semana: Sábado");
		break;
		case 7 : System.out.println("Dia de la semana: Domingo");
		break;
		default : System.out.println("Elige una opción válida");
		}
		
		}while(dia>=8);
		
		do {
		
		System.out.println("¿Pertenece al club Fanegas?(1.si/2.no)");
		
		club = sc.nextInt();
		
		switch(club) {
		case 1 : System.out.println("Perteneces al club, toma un 12% de descuento");
		break;
		case 2 : System.out.println("No perteneces al club, no tienes descuento");
		break;
		default : System.out.println("Elige una opción correcta");
		break;
		}
		
		}while(club>=3);
		
		int preciohamburguesabasica=respuestauno*hamburguesabasica;
		int hamburguesabasicafinal=respuestauno*hamburguesabasica-(respuestauno*1);	
		int descuentomartes = respuestados%2;		
		int preciohamburguesagourmet=respuestados*hamburguesagourmet;
		int hamburguesagourmetfinal=respuestados*hamburguesagourmet-(respuestados/2);
		
		//código para cuando es martes
		
		if(dia==2) {
			if(descuentomartes==0) {
				
				System.out.println("El precio total de tus hamburguesas gourmet es: "+hamburguesagourmetfinal+"€");
				System.out.println("El precio total de tus hamburguesas básicas es: "+preciohamburguesabasica+"€");
				
				if(club==1) {
					
					System.out.println("Como perteneces al club, el precio final se ve reducido un 12 %");
					
					double preciofinal=(hamburguesagourmetfinal+preciohamburguesabasica)-(hamburguesagourmetfinal+preciohamburguesabasica)*0.12;
					
					System.out.println("El precio final es de: "+preciofinal+"€");
					
				}else {
					
					System.out.println("Como no perteneces al club, el precio final no se ve reducido");
					
					int preciofinal=hamburguesagourmetfinal+preciohamburguesabasica;
					
					System.out.println("El precio final es de: "+preciofinal+"€");
				}
				
			}else {
				System.out.println("No has comprado ningún pack de 2 hamburguesas gourmet, siguen costando: "+preciohamburguesagourmet+"€");
				System.out.println("El precio total de tus hamburguesas básicas es: "+preciohamburguesabasica+"€");
				if(club==1) {
					
					System.out.println("Como perteneces al club, el precio final se ve reducido un 12 %");
					
					double preciofinal=(preciohamburguesagourmet+preciohamburguesabasica)-(preciohamburguesagourmet+preciohamburguesabasica)*0.12;
					
					System.out.println("El precio final es de: "+preciofinal+"€");
					
				}else {
					
					System.out.println("Como no perteneces al club, el precio final no se ve reducido");
					
					int preciofinal=preciohamburguesagourmet+preciohamburguesabasica;
					
					System.out.println("El precio final es de: "+preciofinal+"€");
				}
			}
				
			
			}
		
		//código para cuando es miércoles
		
		if (dia==3) {
			System.out.println("Como es miércoles de desmadre, tus hamburguesas básicas cuestan ahora: "+hamburguesabasicafinal+"€");
			System.out.println("El precio total de tus hamburguesas gourmet cuesta: "+preciohamburguesagourmet+"€");
			if(club==1) {
				
				System.out.println("Como perteneces al club, el precio final se ve reducido un 12 %");
				
				double preciofinal=(hamburguesabasicafinal+preciohamburguesagourmet)-(hamburguesabasicafinal+preciohamburguesagourmet)*0.12;
				
				System.out.println("El precio final es de: "+preciofinal+"€");
				
			}else {
				
				System.out.println("Como no perteneces al club, el precio final no se ve reducido");
				
				int preciofinal=hamburguesabasicafinal+preciohamburguesagourmet;
				
				System.out.println("El precio final es de: "+preciofinal+"€");
			}
		}
		
		//código para cuando no es martes ni miércoles 
		
		if (dia != 2 && dia !=3) {
			
			System.out.println("El precio total de tus hamburguesas básicas es de: "+preciohamburguesabasica+"€");
			System.out.println("El precio total de tus hamburguesas gourmet es de: "+preciohamburguesagourmet+"€");
			if(club==1) {
				
				System.out.println("Como perteneces al club, el precio final se ve reducido un 12 %");
				
				double preciofinal=(preciohamburguesabasica+preciohamburguesagourmet)-(preciohamburguesabasica+preciohamburguesagourmet)*0.12;
				
				System.out.println("El precio final es de: "+preciofinal+"€");
				
			}else {
				
				System.out.println("Como no perteneces al club, el precio final no se ve reducido");
				
				int preciofinal=preciohamburguesabasica+preciohamburguesagourmet;
				
				System.out.println("El precio final es de: "+preciofinal+"€");
			}
		}
	}

}
